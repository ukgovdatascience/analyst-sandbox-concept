## Using GOV.UK Verify

[GOV.UK Verify](https://www.gov.uk/government/publications/introducing-govuk-verify/introducing-govuk-verify) is the new way for users to prove who they are whilst using an online service. You can [find out more about using it here](https://www.gov.uk/service-manual/identity-assurance).

If you'd like to test the use of Verify in your prototype, there is a GOV.UK Verify stable prototype you can use.

To use it, you'll need to contact govukverify_engagement@digital.cabinet-office.gov.uk and request access.
